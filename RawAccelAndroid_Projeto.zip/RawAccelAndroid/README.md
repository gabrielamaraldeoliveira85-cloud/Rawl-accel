# RawAccel Android — projeto inicial

Projeto Android Studio (Java) com interface local para configurar e simular curvas Linear, Natural e Power, e parâmetros separados de X/Y.

## Limitação técnica importante
O ZIP original descreve o Raw Accel como um driver de Windows 10 x64 que modifica o fluxo de entrada bruta do mouse em espaço de kernel. O driver `rawaccel.sys` não é compatível com Android. Um aplicativo Android comum, sem suporte do sistema/firmware ou permissões privilegiadas específicas, não pode interceptar e reescrever globalmente os eventos do mouse OTG. Por isso esta versão é um configurador/simulador: não promete alterar a mira nem a aceleração dentro do Free Fire.

## Abrir e compilar
1. Abra esta pasta no Android Studio.
2. Aguarde a sincronização do Gradle (requer Android SDK 35 e conexão para baixar o plugin, se não estiver instalado).
3. Use Build > Build APK(s).

Compatibilidade declarada: Android 6.0 ou superior; testado ainda não. Dispositivo-alvo informado: Redmi Note 13 / Android 15.
