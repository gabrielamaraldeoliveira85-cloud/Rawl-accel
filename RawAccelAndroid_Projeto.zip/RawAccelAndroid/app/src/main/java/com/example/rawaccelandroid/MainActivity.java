package com.example.rawaccelandroid;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.text.InputType;
import java.util.Locale;

public class MainActivity extends Activity {
    int bg = Color.rgb(16,24,39), panel = Color.rgb(28,39,58), blue = Color.rgb(36,107,253);
    TextView xVal, yVal, gainVal, result, status;
    SeekBar xBar, yBar, gainBar;
    Spinner curve;
    @Override public void onCreate(Bundle b) { super.onCreate(b); build(); }
    TextView text(String s, int size, int color) { TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); return t; }
    LinearLayout column() { LinearLayout l=new LinearLayout(this); l.setOrientation(1); l.setPadding(18,14,18,14); return l; }
    void build() {
        ScrollView scroll=new ScrollView(this); LinearLayout root=column(); root.setBackgroundColor(bg); scroll.addView(root);
        TextView title=text("RAWACCEL ANDROID",24,Color.WHITE); title.setGravity(Gravity.CENTER); root.addView(title);
        TextView sub=text("PERFIL DE ACELERAÇÃO • MOUSE OTG",12,0xffaab7cc); sub.setGravity(Gravity.CENTER); root.addView(sub);
        TextView warning=text("MODO DE CONFIGURAÇÃO / SIMULAÇÃO\nO Android não permite que este app injete aceleração global no mouse. Os valores abaixo calculam e exibem uma curva; não alteram a entrada do Free Fire.",13,0xffffd27a); warning.setPadding(14,14,14,14); warning.setBackgroundColor(panel); root.addView(warning);
        root.addView(label("TIPO DE CURVA")); curve=new Spinner(this); String[] types={"Linear", "Natural", "Power"}; ArrayAdapter<String> ad=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,types); curve.setAdapter(ad); root.addView(curve);
        xVal=text("X: 1.00",16,Color.WHITE); root.addView(xVal); xBar=bar(root,100,100);
        yVal=text("Y: 1.00",16,Color.WHITE); root.addView(yVal); yBar=bar(root,100,100);
        gainVal=text("Ganho máximo: 2.00x",16,Color.WHITE); root.addView(gainVal); gainBar=bar(root,200,400);
        result=text("Resultado da simulação: aguardando ajustes",14,0xffcbd5e1); result.setPadding(12,16,12,16); root.addView(result);
        Button reset=new Button(this); reset.setText("RESTAURAR PADRÃO"); root.addView(reset); reset.setOnClickListener(v->{xBar.setProgress(100);yBar.setProgress(100);gainBar.setProgress(200);curve.setSelection(0);update();});
        status=text("Perfil local • não requer permissões especiais",12,0xff8fa1bb); status.setPadding(0,16,0,8); root.addView(status);
        xBar.setOnSeekBarChangeListener(listener()); yBar.setOnSeekBarChangeListener(listener()); gainBar.setOnSeekBarChangeListener(listener()); curve.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onNothingSelected(android.widget.AdapterView<?> p){} public void onItemSelected(android.widget.AdapterView<?> p,View v,int pos,long id){update();}});
        setContentView(scroll); update();
    }
    TextView label(String s){TextView t=text(s,13,0xff8fa1bb);t.setPadding(0,18,0,6);return t;}
    SeekBar bar(LinearLayout root,int value,int max){SeekBar b=new SeekBar(this);b.setMax(max);b.setProgress(value);root.addView(b);return b;}
    SeekBar.OnSeekBarChangeListener listener(){return new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar b,int p,boolean u){update();}public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){}};}
    void update(){if(xBar==null||yBar==null||gainBar==null)return; double x=xBar.getProgress()/100.0, y=yBar.getProgress()/100.0, g=gainBar.getProgress()/100.0; xVal.setText(String.format(Locale.US,"Eixo X: %.2f",x));yVal.setText(String.format(Locale.US,"Eixo Y: %.2f",y));gainVal.setText(String.format(Locale.US,"Ganho máximo: %.2fx",g));String c=curve.getSelectedItem()==null?"Linear":curve.getSelectedItem().toString();double sample=0.5;double response;if(c.equals("Linear"))response=sample*x;else if(c.equals("Natural"))response=(Math.exp(sample*x)-1)/(Math.E-1);else response=Math.pow(sample,Math.max(0.1,x));result.setText(String.format(Locale.US,"Curva %s • entrada de referência 0,50\nX: %.3f | Y: %.3f\nSaída simulada: %.3f\nGanho configurado: %.2fx",c,response*x,response*y,response*g,g));}
}
